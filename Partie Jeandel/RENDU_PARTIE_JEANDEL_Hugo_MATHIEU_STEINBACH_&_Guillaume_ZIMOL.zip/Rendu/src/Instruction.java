class Instruction {
    // Classe mère de Assign et AssignOperator
}
