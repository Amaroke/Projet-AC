public class Value {
    // Classe mère d'Entier et Variable
}
